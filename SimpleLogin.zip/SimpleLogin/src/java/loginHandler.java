/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Justin
 */
public class loginHandler extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    
    protected void doPost(HttpServletRequest req, HttpServletResponse res)throws ServletException , IOException {
        
        String data = "Bruh";
     
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        
        String user=req.getParameter("username");
        String pass=req.getParameter("password");
        
        if( pass.equals("admin")){
            out.print("Hello, " + user);
        
                
        }else{
       out.print("Unsuccessful Login, please try again.");
       req.getRequestDispatcher("index.jsp").include(req,res);
       }
       
        
       /*
        used if using variable replacement in jsp code
       req.setAttribute("data", data);
       req.getRequestDispatcher("/WEB-INF/index.jsp").forward(req,res);
       */
       
       
    }
   // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */


    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */

}
