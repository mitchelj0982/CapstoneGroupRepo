/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 *
 * @author Justin
 */
public class Build {
    String CPU;
    String RAM;
    String GPU;
    
    
    public Build() {
        CPU = "Intel Processor";
        RAM = "GSkill 2GB DDR4 (2x1)";
        GPU = "RTX 3060";
    
    
    }
    
    
    public String getCPU(){
        return CPU;
        
    }
    
    public String getGPU(){
        return GPU;
        
    }
    
    
    public String getRAM(){
        return RAM;
        
    }
    
    
    public void setCPU(String C){
        CPU = C;
        
    }
    
    public void setGPU(String G) {
        GPU = G;
        
    }
    
    public void setRAM(String R){
        RAM = R;

    }
    
    
}
