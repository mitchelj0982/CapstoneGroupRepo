/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;


import java.util.*;
/**
 *
 * @author Justin
 */
public class Handler {
    String username;
    String password;
    
    boolean isLoggedIn;
    int attempt;
    
    public Handler() {
        
        Start();
        
    }
    
    public void setUsername(String u) {
        username = u;
        
        /*
        
        Original code to test loggin in with only a username
        if (u.equals(username)) {
            isLoggedIn = true;
            
        } 
        */
        
        
        
    }
    
        public void setPassword(String p) {
        attempt++;
        if ((p.equals(password)) && (username != "")) {
            isLoggedIn = true;
            
        } 
        
        
        
    }
    
    public String getUsername() {
        return username;
        
    }
    
    public String getPassword() {
        return password;
        
    }
    
    public boolean getIsLoggedIn() {
        return isLoggedIn;
        
    }
    
    public int getAttempt() {
        return attempt;
        
    }
    
    
    public void Start(){
        isLoggedIn = false;
        attempt = 0;
        username = "";
        password = "Admin";
    }
    
    
}
