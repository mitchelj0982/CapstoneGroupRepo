/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Justin
 */
public class Credentials {
    private String username;
    private String password;
    
    String enteredUser;
    String enteredPass;
    
    public Credentials() {
        username = "admin";
        password = "admin";
        
        
    }
    
    
}
