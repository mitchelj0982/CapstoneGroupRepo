/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Justin
 */
public class CPU {
    String partName;
    String partID;
    String socketType;
    int cores;
    int threads;
    
    public CPU() {
        partName = "Default CPU";
        partID = "000";
        socketType = " Default Socket";
        cores = 0;
        threads = 0;
        
    }
    
    //GETTERS
    
    public  String getPartName(){
        return partName;
    }
    
    public  String getPartID(){
        return partID;
    }
    
    public String getSocketType(){
        return socketType;
    }
    
    public  int getCores() {
        return cores;
    }
    
    public  int getThreads() {
        return threads;
    }
    
    
    //SETTERS
    
    public void setPartName(String n){
        partName = n;
    }
    
    public void setPartID(String id){
        partID = id;
    }
    
        public void setSocketType(String st){
        socketType = st;
    }
    
    public void setCores(int c){
        cores = c;
    }
    
    public void setThreads(int th){
        threads = th;
    }
    
}
