/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Justin
 */
public class RAM {
    String partName;
    String partID;
    String slotType;
    int gigs;
    int numSticks;
    public RAM(){
        partName = "Default RAM";
        partID = "0000";
        slotType = "DDR4";
        gigs = 8;
        numSticks = 4;
        
    }
    
    //GETTERS
    public  String getPartName(){
        return partName;
    }
    
    public  String getPartID(){
        return partID;
    }

    public String getSlotType(){
        return slotType;
    }
    
    public int getGigs(){
        return gigs;
    }
    
    public int getNumSticks(){
        return numSticks;
    }
    
    
    //SETTERS
    
    public void setNumSticks(int n){
        numSticks = n;
        
    }
    
    public void setGigs(int g){
        gigs = g;
    }
    
    public void setSlotType(String t){
        slotType = t;
    }
    
    public void setPartName(String n){
        partName = n;
    }
    
    public void setPartID(String id){
        partID = id;
    }
}
