/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Justin
 */
public class Motherboard {
    String partName;
    String partID;
    String socketType;
    String slotType;
    String size;
    
    public Motherboard() {
        partName = "Default MOBO";
        partID = "0000";
        slotType = "DDR4";        
        socketType = "Default Socket";   
        size = "ATX";
    }
    
    //GETTERS
    
    public String getSize(){
        return size;
    }

    public  String getPartName(){
        return partName;
    }
    
    public  String getPartID(){
        return partID;
    }    
    
    public String getSocketType(){
        return socketType;
    }  
    
    public String getSlotType(){
        return slotType;
    }    
    
    
    
    //SETTERS
    
    
    public void setSize(String s){
        size = s;
    } 
    
    public void setSocketType(String st){
        socketType = st;
    }
    public void setSlotType(String t){
        slotType = t;
    }
    
    public void setPartName(String n){
        partName = n;
    }
    
    public void setPartID(String id){
        partID = id;
    }    
    
    
}
