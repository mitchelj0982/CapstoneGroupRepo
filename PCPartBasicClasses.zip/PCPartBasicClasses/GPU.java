/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Justin
 */
public class GPU {
    
    String partName;
    String partID;
    int VRAM;
    
    public GPU() {
        partName = "Default GPU";
        partID = "0000";
        VRAM = 8;
                
        
    }
    //GETTERS
    
    public int getVRAM(){
        return VRAM;
    }

    public  String getPartName(){
        return partName;
    }
    
    public  String getPartID(){
        return partID;
    }
    
    //SETTERS
    
    public void setVRAM(int v){
        VRAM = v;
    }
    public void setPartName(String n){
        partName = n;
    }
    
    public void setPartID(String id){
        partID = id;
    }      
}
