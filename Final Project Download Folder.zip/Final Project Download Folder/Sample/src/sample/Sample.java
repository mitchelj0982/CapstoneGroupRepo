/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sample;

/**
 *
 * @author strotheb6455
 */

    
    public class Sample
    {
      public static void main(String[] args) 
      {
        new login_page_frame().setVisible(true);
        //new reg_page_frame().setVisible(true);
        //new build_page_frame().setVisible(true);
        
      }
    }